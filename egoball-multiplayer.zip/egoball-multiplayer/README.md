# EgoBall Multiplayer

Server tomonida hisoblanadigan (server-authoritative) multiplayer futbol o'yini.
Telefon va kompyuterda ishlaydi, to'liq ekran (fullscreen) tugmasi bor.

## O'rnatish

1. Node.js o'rnatilgan bo'lishi kerak (nodejs.org).
2. Terminalda shu papkaga kiring:
   ```
   cd egoball-multiplayer
   ```
3. Kerakli kutubxonalarni o'rnating:
   ```
   npm install
   ```
4. Serverni ishga tushiring:
   ```
   npm start
   ```
5. Brauzerda oching: `http://localhost:3000`
   Telefondan sinash uchun kompyuter va telefon bir xil Wi-Fi'da bo'lishi kerak,
   keyin telefon brauzerida: `http://<kompyuter-IP>:3000`

## Qanday ishlaydi

- **accounts.js** — ro'yxatdan o'tish/kirish, `users.json` faylida saqlanadi (parollar hash qilinadi).
- **server.js** — barcha fizika (harakat, to'qnashuv, gol) shu yerda, 60 marta/sekundda hisoblanadi.
  Client faqat "qaysi tomonga yuryapman" va "uryapmanmi" degan ma'lumot yuboradi — pozitsiyani
  hech qachon o'zi yubormaydi, shuning uchun speed-hack yoki teleport-cheat qilib bo'lmaydi.
- **public/index.html** — ko'rinadigan qism: canvas render, klaviatura (kompyuter),
  virtual joystick + urish tugmasi (telefon), va fullscreen tugmasi.

## Keyingi qadamlar (xohlasangiz)

- Bir nechta xona (bir vaqtda bir nechta match) qo'shish
- Dizaynni Egoball uslubiga moslashtirish (ranglar, fon, logotip)
- Kuchliroq anti-cheat: input tezligini serverda tekshirish, rate-limit
- Match tarixi, reyting jadvali (leaderboard)

Hozirgi versiya — ishlaydigan, o'ynasa bo'ladigan asos. Shundan keyin ustiga qo'shib boramiz.
